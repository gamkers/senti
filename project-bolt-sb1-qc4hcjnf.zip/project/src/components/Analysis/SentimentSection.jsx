import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../common/SectionTitle';
import SentimentCharts from './SentimentCharts';
import SentimentStats from './SentimentStats';

const SentimentSection = () => {
  return (
    <section id="sentiment" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle
          title="Sentiment Analysis"
          subtitle="Understanding the emotional pulse of Chennai through data"
        />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8"
        >
          <SentimentStats />
          <SentimentCharts />
        </motion.div>
      </div>
    </section>
  );
};

export default SentimentSection;