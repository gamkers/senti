import React from 'react';
import { motion } from 'framer-motion';
import { useSentimentData } from '../../hooks/useSentimentData';

const SentimentStats = () => {
  const { averageScore, totalPosts } = useSentimentData();

  const stats = [
    {
      title: 'Average Sentiment Score',
      value: averageScore.toFixed(1),
      subtitle: 'out of 10',
      color: 'from-purple-500 to-pink-500',
    },
    {
      title: 'Total Posts Analyzed',
      value: totalPosts,
      subtitle: 'personal stories',
      color: 'from-blue-500 to-teal-500',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          viewport={{ once: true }}
          className="bg-gray-800 rounded-xl p-6 shadow-xl"
        >
          <h3 className="text-lg font-medium text-gray-300 mb-2">{stat.title}</h3>
          <div className={`text-4xl font-bold bg-gradient-to-r ${stat.color} text-transparent bg-clip-text`}>
            {stat.value}
          </div>
          <p className="text-sm text-gray-400 mt-1">{stat.subtitle}</p>
        </motion.div>
      ))}
    </div>
  );
};

export default SentimentStats;