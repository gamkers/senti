import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';
import { motion } from 'framer-motion';
import { useSentimentData } from '../../hooks/useSentimentData';

ChartJS.register(ArcElement, Tooltip, Legend);

const SentimentCharts = () => {
  const { sentimentDistribution, averageScore } = useSentimentData();

  const data = {
    labels: Object.keys(sentimentDistribution),
    datasets: [
      {
        data: Object.values(sentimentDistribution),
        backgroundColor: [
          'rgba(147, 51, 234, 0.8)', // Purple
          'rgba(236, 72, 153, 0.8)', // Pink
        ],
        borderColor: [
          'rgba(147, 51, 234, 1)',
          'rgba(236, 72, 153, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          color: '#9CA3AF',
          font: {
            size: 14,
          },
        },
      },
      tooltip: {
        backgroundColor: 'rgba(17, 24, 39, 0.9)',
        titleColor: '#F3F4F6',
        bodyColor: '#D1D5DB',
        borderColor: '#4B5563',
        borderWidth: 1,
      },
    },
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="bg-gray-800 rounded-xl p-6 shadow-xl"
    >
      <h3 className="text-xl font-semibold text-gray-200 mb-6 text-center">
        Sentiment Distribution
      </h3>
      <div className="max-w-md mx-auto">
        <Doughnut data={data} options={options} />
      </div>
    </motion.div>
  );
};

export default SentimentCharts;