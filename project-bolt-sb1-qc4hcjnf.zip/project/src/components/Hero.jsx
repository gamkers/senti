import React from 'react';
import { motion } from 'framer-motion';

const Hero = () => {
  return (
    <section id="home" className="pt-20 min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600 mb-6">
            Yammer Insights with LLM
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Discover the power of sentiment analysis through our advanced LLM technology, 
            analyzing real Yammer posts about Chennai to uncover meaningful insights and 
            experiences.
          </p>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="bg-gray-800 p-6 rounded-lg shadow-xl max-w-2xl mx-auto"
          >
            <h2 className="text-xl font-semibold mb-4 text-purple-400">
              Sentiment Analysis Overview
            </h2>
            <p className="text-gray-300">
              Our LLM-powered analysis examines user posts to understand the emotional 
              context and sentiment behind experiences in Chennai. Through natural 
              language processing, we identify key themes, locations, and sentiments 
              to provide valuable insights into the city's impact on its residents 
              and visitors.
            </p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;