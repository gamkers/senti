import React from 'react';
import { motion } from 'framer-motion';
import { FaMapMarkerAlt } from 'react-icons/fa';

const PlaceCard = ({ place }) => {
  const { name, mentions, image } = place;

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="bg-gray-900 rounded-lg shadow-xl overflow-hidden h-full"
    >
      <div 
        className="h-48 bg-cover bg-center"
        style={{
          backgroundImage: `url(${image})`,
        }}
      >
        <div className="w-full h-full bg-gradient-to-t from-gray-900 to-transparent" />
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-100 mb-2">{name}</h3>
        <div className="flex items-center text-purple-400">
          <FaMapMarkerAlt className="mr-2" />
          <span className="text-sm">{mentions} mentions</span>
        </div>
      </div>
    </motion.div>
  );
};

export default PlaceCard;