import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import PlaceCard from './PlaceCard';
import { usePlacesData } from '../../hooks/usePlacesData';

const PlacesSlider = () => {
  const { topPlaces } = usePlacesData();

  return (
    <Swiper
      modules={[Navigation, Pagination, Autoplay]}
      spaceBetween={30}
      slidesPerView={1}
      navigation
      pagination={{ clickable: true }}
      autoplay={{ delay: 4000, disableOnInteraction: false }}
      breakpoints={{
        640: {
          slidesPerView: 2,
        },
        1024: {
          slidesPerView: 3,
        },
      }}
      className="places-slider"
    >
      {topPlaces.map((place, index) => (
        <SwiperSlide key={index}>
          <PlaceCard place={place} />
        </SwiperSlide>
      ))}
    </Swiper>
  );
};

export default PlacesSlider;