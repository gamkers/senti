import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import PostCard from './PostCard';
import { posts } from '../../data/posts';

import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

const PostSlider = () => {
  return (
    <Swiper
      modules={[Navigation, Pagination, Autoplay]}
      spaceBetween={30}
      slidesPerView={1}
      navigation
      pagination={{ clickable: true }}
      autoplay={{ delay: 5000, disableOnInteraction: false }}
      breakpoints={{
        640: {
          slidesPerView: 2,
        },
        1024: {
          slidesPerView: 3,
        },
      }}
      className="posts-slider"
    >
      {posts.map((post, index) => (
        <SwiperSlide key={index}>
          <PostCard post={post} />
        </SwiperSlide>
      ))}
    </Swiper>
  );
};

export default PostSlider;