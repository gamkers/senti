import React from 'react';
import { motion } from 'framer-motion';
import { FaStar } from 'react-icons/fa';

const PostCard = ({ post }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="bg-gray-900 rounded-lg shadow-xl p-6 h-full flex flex-col"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <FaStar className="text-yellow-500" />
          <span className="text-yellow-500 font-semibold">
            Score: {post.score}/10
          </span>
        </div>
        <span className="text-purple-400 text-sm">
          Sentiment: {post.sentiment}
        </span>
      </div>
      
      <div className="flex-grow">
        <p className="text-gray-300 text-sm mb-4 line-clamp-4">
          {post.post.substring(0, 200)}...
        </p>
        
        {(post.keywords?.places?.length > 0 || post.keywords?.food?.length > 0) && (
          <div className="mt-4">
            {post.keywords.places?.length > 0 && (
              <div className="mb-2">
                <span className="text-purple-400 text-xs font-semibold">Places mentioned:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {post.keywords.places.slice(0, 3).map((place, index) => (
                    <span
                      key={index}
                      className="text-xs bg-gray-800 text-gray-300 px-2 py-1 rounded"
                    >
                      {place}
                    </span>
                  ))}
                </div>
              </div>
            )}
            
            {post.keywords.food?.length > 0 && (
              <div>
                <span className="text-purple-400 text-xs font-semibold">Food mentioned:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {post.keywords.food.slice(0, 3).map((food, index) => (
                    <span
                      key={index}
                      className="text-xs bg-gray-800 text-gray-300 px-2 py-1 rounded"
                    >
                      {food}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default PostCard;