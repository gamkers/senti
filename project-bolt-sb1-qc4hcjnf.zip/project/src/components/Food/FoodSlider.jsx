import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import FoodCard from './FoodCard';
import { useFoodData } from '../../hooks/useFoodData';

const FoodSlider = () => {
  const { topFoods } = useFoodData();

  return (
    <Swiper
      modules={[Navigation, Pagination, Autoplay]}
      spaceBetween={30}
      slidesPerView={1}
      navigation
      pagination={{ clickable: true }}
      autoplay={{ delay: 3500, disableOnInteraction: false }}
      breakpoints={{
        640: {
          slidesPerView: 2,
        },
        1024: {
          slidesPerView: 3,
        },
      }}
      className="food-slider"
    >
      {topFoods.map((food, index) => (
        <SwiperSlide key={index}>
          <FoodCard food={food} />
        </SwiperSlide>
      ))}
    </Swiper>
  );
};

export default FoodSlider;