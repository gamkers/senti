import React from 'react';
import { motion } from 'framer-motion';
import { FaUtensils } from 'react-icons/fa';

const FoodCard = ({ food }) => {
  const { name, mentions, image } = food;

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="bg-gray-900 rounded-lg shadow-xl overflow-hidden h-full"
    >
      <div 
        className="h-48 bg-cover bg-center relative"
        style={{
          backgroundImage: `url(${image})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/40 to-transparent" />
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="absolute bottom-4 right-4 bg-purple-500 rounded-full p-2"
        >
          <FaUtensils className="text-white text-xl" />
        </motion.div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-100 mb-2">{name}</h3>
        <div className="flex items-center text-purple-400">
          <span className="text-sm">{mentions} mentions in stories</span>
        </div>
      </div>
    </motion.div>
  );
};

export default FoodCard;