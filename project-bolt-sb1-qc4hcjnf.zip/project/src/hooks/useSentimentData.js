import { useMemo } from 'react';
import { posts } from '../data/posts';

export const useSentimentData = () => {
  const data = useMemo(() => {
    const sentimentDistribution = posts.reduce((acc, post) => {
      acc[post.sentiment] = (acc[post.sentiment] || 0) + 1;
      return acc;
    }, {});

    const totalPosts = posts.length;
    const averageScore = posts.reduce((sum, post) => sum + post.score, 0) / totalPosts;

    return {
      sentimentDistribution,
      averageScore,
      totalPosts,
    };
  }, []);

  return data;
};