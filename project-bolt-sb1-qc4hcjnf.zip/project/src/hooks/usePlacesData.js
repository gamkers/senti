import { useMemo } from 'react';
import { posts } from '../data/posts';

const getPlaceImage = (placeName) => {
  // You can replace these with actual image URLs
  const defaultImage = 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&q=80';
  
  const placeImages = {
    'Marina Beach': 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&q=80',
    'Kapaleeshwarar Temple': 'https://images.unsplash.com/photo-1621831714462-bec486687d0f?auto=format&fit=crop&q=80',
    'T Nagar': 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&q=80',
  };

  return placeImages[placeName] || defaultImage;
};

export const usePlacesData = () => {
  const data = useMemo(() => {
    // Count place mentions across all posts
    const placeMentions = {};
    posts.forEach(post => {
      if (post.keywords?.places) {
        post.keywords.places.forEach(place => {
          placeMentions[place] = (placeMentions[place] || 0) + 1;
        });
      }
    });

    // Convert to array and sort by mentions
    const topPlaces = Object.entries(placeMentions)
      .map(([name, mentions]) => ({
        name,
        mentions,
        image: getPlaceImage(name),
      }))
      .sort((a, b) => b.mentions - a.mentions)
      .slice(0, 9); // Get top 9 places

    return {
      topPlaces,
    };
  }, []);

  return data;
};