import { useMemo } from 'react';
import { posts } from '../data/posts';

const getFoodImage = (foodName) => {
  // You can replace these with actual food image URLs
  const defaultImage = 'https://images.unsplash.com/photo-1505253304499-671c55fb57fe?auto=format&fit=crop&q=80';
  
  const foodImages = {
    'South India food': 'https://images.unsplash.com/photo-1630383249896-424e482df921?auto=format&fit=crop&q=80',
    'Chettinadu food': 'https://images.unsplash.com/photo-1589647363585-f4a7d3877b10?auto=format&fit=crop&q=80',
    'Burmese food': 'https://images.unsplash.com/photo-1626804475297-41608ea09aeb?auto=format&fit=crop&q=80',
  };

  return foodImages[foodName] || defaultImage;
};

export const useFoodData = () => {
  const data = useMemo(() => {
    // Count food mentions across all posts
    const foodMentions = {};
    posts.forEach(post => {
      if (post.keywords?.food) {
        post.keywords.food.forEach(food => {
          foodMentions[food] = (foodMentions[food] || 0) + 1;
        });
      }
    });

    // Convert to array and sort by mentions
    const topFoods = Object.entries(foodMentions)
      .map(([name, mentions]) => ({
        name,
        mentions,
        image: getFoodImage(name),
      }))
      .sort((a, b) => b.mentions - a.mentions);

    return {
      topFoods,
    };
  }, []);

  return data;
};