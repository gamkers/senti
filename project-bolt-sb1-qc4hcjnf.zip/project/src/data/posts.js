export const posts = [
  {
    "sentiment": "Positive",
    "justification": "The post expresses a positive sentiment towards Chennai, as the user has a deep connection with the city, having worked there for 7 years and having many great memories associated with it.",
    "score": 9,
    "keywords": {
      "places": [
        "Madras (Chennai)",
        "Ranganathan Street T Nagar",
        "Kilpauk",
        "Anna Nagar East and West"
      ],
      "food": [
        "South India food",
        "Chettinadu food"
      ]
    },
    "post": "Madras (Chennai), is very closed to my heart, as it was my first karma bhoomi (Place of work) after I left Nagpur in 1998. I had spent 7 years in Chennai, before I moved to Pune in 2005..."
  },
  // Add all other posts here...
];