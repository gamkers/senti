import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import PostsSection from './components/Posts/PostsSection';
import SentimentSection from './components/Analysis/SentimentSection';
import PlacesSection from './components/Places/PlacesSection';
import FoodSection from './components/Food/FoodSection';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Navbar />
      <Hero />
      <PostsSection />
      <SentimentSection />
      <PlacesSection />
      <FoodSection />
    </div>
  );
}

export default App;